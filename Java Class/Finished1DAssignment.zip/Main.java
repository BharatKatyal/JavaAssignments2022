import java.util.Random;
import java.util.Arrays;
import java.util.Scanner;

class Main{
	// Function to calculate the frequency of all elements in the array
	public static void findFrequency(int[] A)
	{
		// create a count array of size `n` to store the count of all array elements
		int[] freq = new int[A.length];

		// update frequency of each element
		for (int e: A) {
			freq[e]++;
		} // end of for loop

		// iterate through the array to print frequencies
		for (int i = 0; i < freq.length; i++){
			if (freq[i] > 0) {
				System.out.printf("%d appears %d times\n", i, freq[i]);
			} // End of if statement
		}// End of for loop to print array of frequencies 
	} // End of findFrequency

	public static void main(String[] args){

    Random rand = new Random();
    Scanner input = new Scanner(System.in);
	  int upperbound = 100;
    int randomNumbers[];


    System.out.print("Enter how many random values you would like: ");
		int arraySize = input.nextInt();
		randomNumbers = new int[arraySize]; 

    
    	for(int i =0; i<randomNumbers.length; i++) {
			randomNumbers[i]= rand.nextInt(upperbound);
		} // End of For Loop


		Arrays.sort(randomNumbers); 
    MinAndMaxAndAvg m =  new MinAndMaxAndAvg();


    // for(int j =0; j<randomNumbers.length; j++) {
		// 	System.out.println(randomNumbers[j]);
			
		// }// End of four loop printing inital numbers 


  System.out.println("This is the Highest Value In the Array: " + m.max(randomNumbers));
		System.out.println("This is Lowest Value In te Array: " + m.min(randomNumbers));
		System.out.println("Just to make sure everythigns functioning fine! This is length of the array : " +randomNumbers.length);

		System.out.println("This is average of all the numbers in the array :  "+ m.avg(randomNumbers));

		System.out.println(" ****** Belowis the array sorted with frequency ****** ");



		findFrequency(randomNumbers);
	}// End of Main
}
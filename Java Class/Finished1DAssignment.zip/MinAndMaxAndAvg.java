import java.util.Arrays;


public class MinAndMaxAndAvg {

	public int max(int[] array) {
		// TODO Auto-generated method stub
int max =0;

for(int i =0; i<array.length; i++) {
	
	 if(array[i]>max) {
         max = array[i];
      }// end of if statement 
} // end of for loop
return max;

	}// ENd of max
	
	public int min(int[] array) {
		// TODO Auto-generated method stub
int min =array[0];

for(int i =0; i<array.length; i++) {
	
	if(array[i]<min) {
        min = array[i];
     }// end of if statement
}// end of for loop
return min;

	}// END OF MIN
	public double avg(int[] array) {
		// TODO Auto-generated method stub
double avg =0d;

for(int i =0; i<array.length; i++) {
	avg = array[i]+ avg;
     }// end of for loop
return avg/array.length;

}// end of average

}// end of MinAndMaxAndAvg
